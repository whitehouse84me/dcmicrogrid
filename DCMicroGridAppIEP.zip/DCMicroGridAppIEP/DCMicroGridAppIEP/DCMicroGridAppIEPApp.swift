//
//  DCMicroGridAppIEPApp.swift
//  DCMicroGridAppIEP
//
//  Created by White Dana on 23/7/21.
//

import SwiftUI

@main
struct DCMicroGridAppIEPApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
